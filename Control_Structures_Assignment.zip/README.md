# Python Control Structures Assignment

This repository contains two Python scripts created for Assignment 2 - Module 3: Control Structures in Python.

## 🧩 Tasks

### Task 1: Check if a Number is Even or Odd
- Takes an integer input.
- Checks whether the number is even or odd using an if-else statement.
- Displays the result.

### Task 2: Sum of Integers from 1 to 50 Using a Loop
- Uses a for loop to iterate through numbers from 1 to 50.
- Calculates and displays the sum.

## 💾 Files Included
- `even_or_odd.py` – Solution for Task 1.
- `sum_1_to_50.py` – Solution for Task 2.

## 🚀 How to Run
Run each script using:
```bash
python filename.py
```

Replace `filename.py` with `even_or_odd.py` or `sum_1_to_50.py`.

## 🔄 Reference
This project is based on Module 3: Control Structures in Python from the Python course.
